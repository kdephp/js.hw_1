window.addEventListener('load', function(){

	let inp1 = document.querySelector('.inp1');
	let inp2 = document.querySelector('.inp2');
	let btn = document.querySelector('.go');
	let res = document.querySelector('.res');
	let operation = document.querySelector('select');

	const calculate = (inp1, operator, inp2) => {
		let result = ''
		
		if (operator === 'add') {
		  result = parseFloat(inp1) + parseFloat(inp2)
		} else if (operator === 'subtract') {
		  result = parseFloat(inp1) - parseFloat(inp2)
		} else if (operator === 'multiply') {
		  result = parseFloat(inp1) * parseFloat(inp2)
		} else if (operator === 'divide') {
		  result = parseFloat(inp1) / parseFloat(inp2)
		}
		
		return result
	  }

	  function alerted(){
		alert("Вы нажали на кнопку");
	  }
	




});

